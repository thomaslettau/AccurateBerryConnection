#!/usr/bin/env bash


ap="aurora:/beegfs/pa74roz/qe/MoS2"

mkdir scf
scp $ap/scf/*.in scf/
scp $ap/scf/MoS2.pw scf/MoS2.scf


for i in {16..25}; do
    p="$ap/${i}x${i}x1"
    out="${i}x${i}x1"
    mkdir $out
    scp $p/MoS2.nscf $out/
    scp $p/MoS2.win $out/
    scp $p/MoS2.pw2wan $out/
    for s in "cb" "vb" "full" ; do 
        dr=$s
        if [ $s == "full" ] ; then
            dr="cb-vb"
        fi
        mkdir $out/$dr
        scp ${p}/$s/MoS2.win $out/$dr/
    done
done
