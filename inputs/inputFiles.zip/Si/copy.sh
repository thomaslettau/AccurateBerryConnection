#!/usr/bin/env bash


ap="aurora:/beegfs/pa74roz/qe/Si/kScan"

mkdir scf
scp $ap/scf/*.in scf/
scp $ap/scf/silicon.scf scf/


for i in {5..15}; do
    p="$ap/${i}x${i}x${i}"
    out="${i}x${i}x${i}"
    mkdir $out
    scp $p/silicon.nscf $out/
    scp $p/silicon.win $out/
    scp $p/silicon.pw2wan $out/
    #for s in "cb" "vb" "full" ; do 
    #    dr=$s
    #    if [ $s == "full" ] ; then
    #        dr="cb-vb"
    #    fi
    #    mkdir $out/$dr
    #    scp ${p}/$s/silicon.win $out/$dr/
    #done
done
